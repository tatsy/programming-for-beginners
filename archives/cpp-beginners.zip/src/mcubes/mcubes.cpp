#include "mcubes.h"

#include <climits>
#include <algorithm>
#include <unordered_map>



#include "common/array3d.h"
#include "common/progress.h"
#include "mcubes_utils.h"

double getThresholdOtsu(const Volume &volume) {
    NOT_IMPL_ERROR();





}

void marchCubes(const Volume &volume, std::vector<Vec3> *vertices, std::vector<uint32_t> *indices, double threshold, bool flipFaces) {
    // Clear arrays
    vertices->clear();
    indices->clear();

    // Compute threshold with Otsu's method, if threshold is not specified.
    if (threshold < 0.0) {
        threshold = getThresholdOtsu(volume);
    }
    printf("Threshold: %.5f\n", threshold);

    // Marching cubes
    GRIDCELL cell;
    TRIANGLE tris[16];
    const Vec3 resolution = Vec3(1.0, 1.0, 1.0);

    // See: "http://paulbourke.net/geometry/polygonise/"
    // Vertex ordering in the cube is rather wired, and
    // the array below re-orders the vertices for easy bit masking.
    static int indexTable[8] = { 0, 1, 4, 5, 3, 2, 7, 6 };

    ProgressBar pbar((volume.size(1) - 1) * (volume.size(2) - 1));
    std::unordered_map<Vec3, uint32_t> uniqueVertices;
    for (uint64_t z = 0; z < volume.size(2) - 1; z++) {
        for (uint64_t y = 0; y < volume.size(1) - 1; y++) {
            for (uint64_t x = 0; x < volume.size(0) - 1; x++) {
                NOT_IMPL_ERROR();



            }
            pbar.step();
        }
    }

    printf("#vert: %d\n", (int)vertices->size());
    printf("#face: %d\n", (int)indices->size() / 3);
}



    // Clear arrays

    // Compute threshold with Otsu's method, if threshold is not specified.

    // Marching tetrahedra

    // See: "http://paulbourke.net/geometry/polygonise/"
    // Vertex ordering in the cube is rather wired, and
    // the array below re-orders the vertices for easy bit masking.







    // Clear arrays

    // Compute threshold with Otsu's method, if threshold is not specified.

    // Compute normals

    // Check intersection between cube edges and iso-contours

    // X axis

    // Y axis

    // Z axis

    // Define vertex positions of iso-surface

                // X axis


                // Y axis


                // Z axis




//                    EigenVector3 cc;
//                    cc << avg.x, avg.y, avg.z;

//                    const double beta = 1.0e-2;
//                    const EigenVector3 xx = (AA + beta * II).ldlt().solve(bb + beta * cc);


    // Dual contouring


    // X axis



    // Y axis



    // Z axis




